const jwt = require('jsonwebtoken');

/**
 * Generates a JWT token.
 * @param {Object} payload - The payload to include in the JWT.
 * @returns {String} - The signed JWT token.
 */
const generateToken = (payload) => {
  // Ensure that JWT_SECRET is set in your .env file
  if (!process.env.JWT_SECRET) {
    throw new Error('JWT_SECRET is not defined in the environment variables');
  }

  // Sign the token with the payload and secret
  const token = jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: '1h', // Token expires in 1 hour
  });

  return token;
};

module.exports = { generateToken };
