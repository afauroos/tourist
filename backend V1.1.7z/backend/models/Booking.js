const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define traveler schema
const travelerSchema = new Schema({
  id: String,
  dateOfBirth: String,
  name: {
    firstName: String,
    lastName: String,
  },
  gender: String,
  contact: {
    emailAddress: String,
    phones: [
      {
        deviceType: String,
        countryCallingCode: String,
        number: String,
      }
    ]
  },
  documents: [
    {
      documentType: String,
      number: String,
      expiryDate: String,
      issuanceCountry: String,
      nationality: String,
      birthPlace: String
    }
  ]
});

// Define booking schema
const bookingSchema = new mongoose.Schema({
  flightId: String,
  userId: {
    type: mongoose.Schema.Types.ObjectId, // Ensures userId is stored as ObjectId
    required: true,
    ref: 'User', // Assuming you have a User model
  },
  travelers: Array,
  bookingDetails: Object,
}, { timestamps: true });

module.exports = mongoose.model('Booking', bookingSchema);
