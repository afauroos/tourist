const User = require('../models/User'); 
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { generateToken } = require('../utils/jwtUtils');

// Registration logic
exports.register = async (req, res) => {
  const { email, password } = req.body;

  try {
    // Check if the user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'User already exists' });
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new user
    const user = new User({ email, password: hashedPassword });
    await user.save();

    // Generate the token with the user ID
    const tokenPayload = { userId: user._id, email: user.email };
    const token = generateToken(tokenPayload);

    res.status(201).json({ message: 'User registered successfully', token });
  } catch (error) {
    console.error('Error during registration:', error); 
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Login logic
exports.login = async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    // Generate the token with user info as payload
    const tokenPayload = { userId: user._id, email: user.email };
    const token = generateToken(tokenPayload);

    res.json({ token });
  } catch (error) {
    console.error('Error during login:', error); 
    res.status(500).json({ message: 'Server error' });
  }
};

// Get Profile logic
exports.getProfile = async (req, res) => {
  try {
    // Use the userId from the token payload
    const user = await User.findById(req.user.userId).select('-password'); 
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json(user);
  } catch (error) {
    console.error('Error fetching profile:', error);
    res.status(500).json({ message: 'Server error' });
  }
};
