const { bookFlightAmadeus, confirmFlightAmadeus, getFlightOrderById, cancelFlightOrder } = require('../services/amadeusService');
//const { getFlightOrderById } = require('../services/amadeusService');
const Booking = require('../models/Booking');
const mongoose = require('mongoose'); // Import mongoose

// Controller for confirming flight pricing
exports.confirmFlight = async (req, res) => {
  try {
    // Ensure the incoming request has the correct structure
    const flightOffer = req.body.data?.flightOffers?.[0];

    if (!flightOffer) {
      return res.status(400).json({ error: "Invalid or missing flight offer data" });
    }

    // Call the Amadeus service to confirm flight pricing
    const response = await confirmFlightAmadeus(flightOffer);

    // Return the confirmed flight pricing response
    res.status(200).json(response);
  } catch (error) {
    console.error('Error confirming flight pricing:', error.response ? error.response.data : error.message);
    res.status(500).json({ error: error.response ? error.response.data : 'Failed to confirm flight pricing' });
  }
};

// Controller for booking a flight
exports.bookFlight = async (req, res) => {
  try {
    // Ensure the incoming request has the correct structure
    const flightOffer = req.body.data?.flightOffers?.[0];
    const travelers = req.body.data?.travelers;

    if (!flightOffer || !Array.isArray(travelers) || travelers.length === 0) {
      return res.status(400).json({ error: "Invalid or missing flight offer/travelers data" });
    }

    // Call the Amadeus service to book the flight
    const bookingResponse = await bookFlightAmadeus(flightOffer, travelers);

    // Save the booking details to the database if the booking is successful
    const newBooking = new Booking({
      flightId: flightOffer.id,
      userId: req.user.userId, // Use req.user.userId from the token payload
      travelers,
      bookingDetails: bookingResponse,
    });
    await newBooking.save();

    // Return the booking response to the client
    res.status(200).json(bookingResponse);
  } catch (error) {
    console.error('Error booking flight:', error.response ? error.response.data : error.message);
    res.status(500).json({ error: error.response ? error.response.data : 'Failed to book flight' });
  }
};

// Controller to get all bookings for the logged-in user
exports.getUserBookings = async (req, res) => {
  try {
    const userId = req.user.userId; // Retrieve user ID from the JWT

    const bookings = await Booking.find({ userId }).sort({ createdAt: -1 });

    if (!bookings.length) {
      return res.status(404).json({ message: "No bookings found for this user" });
    }

    res.status(200).json(bookings);
  } catch (error) {
    console.error("Error fetching user bookings:", error);
    res.status(500).json({ message: "Server error, unable to fetch bookings" });
  }
};

// Controller to get a specific booking by its ID (from our database or Amadeus)
exports.getBookingById = async (req, res) => {
  try {
    const { bookingId } = req.params;

    // Ensure bookingId is a valid ObjectId
    if (!mongoose.Types.ObjectId.isValid(bookingId)) {
      return res.status(400).json({ message: "Invalid booking ID format" });
    }

    // Convert bookingId to ObjectId
    const objectId = new mongoose.Types.ObjectId(bookingId);

    // Fetch the booking by ID in your local database
    const booking = await Booking.findOne({ _id: objectId, userId: req.user.userId });

    if (!booking) {
      return res.status(404).json({ message: "Booking not found" });
    }

    // Retrieve flightId from booking details
    const flightId = booking.bookingDetails.id;
    console.log('Flight ID being retrieved from booking details:', flightId);

    // Use Amadeus API to retrieve the flight order details
    const flightOrderDetails = await getFlightOrderById(flightId);

    // Return combined booking and flight order details
    res.status(200).json({
      booking,
      flightOrderDetails,
    });
  } catch (error) {
    console.error("Error fetching booking:", error.message || error);
    res.status(500).json({ message: "Server error, unable to fetch booking" });
  }
};

// Controller to cancel a booking
exports.cancelBooking = async (req, res) => {
  try {
    const { bookingId } = req.params; // Extract booking ID from URL params

    // Find the booking in our system
    const booking = await Booking.findOne({ _id: bookingId, userId: req.user.userId });

    if (!booking) {
      return res.status(404).json({ message: "Booking not found" });
    }

    // Call Amadeus API to cancel the flight order
    const cancellationResponse = await cancelFlightOrder(booking.bookingDetails.id);

    // Remove the booking from our database
    await Booking.deleteOne({ _id: bookingId });

    // Respond to the client
    res.status(200).json({ message: "Booking canceled successfully", cancellationResponse });
  } catch (error) {
    console.error("Error canceling booking:", error.message);
    res.status(500).json({ message: "Server error, unable to cancel booking" });
  }
};
