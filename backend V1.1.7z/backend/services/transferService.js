const Amadeus = require('amadeus');

const amadeus = new Amadeus({
  clientId: process.env.AMADEUS_CLIENT_ID,
  clientSecret: process.env.AMADEUS_CLIENT_SECRET
});

// Function to search for transfers
const searchTransfers = async (transferData) => {
  try {
    const response = await amadeus.shopping.transferOffers.post(
      JSON.stringify(transferData)
    );
    return response.data;
  } catch (error) {
    console.error('Error fetching transfer data:', error);
    throw error;
  }
};

// Function to book a transfer
const bookTransfer = async (bookingData) => {
  try {
    const response = await amadeus.booking.transferOrders.post(
      JSON.stringify(bookingData)
    );
    return response.data;
  } catch (error) {
    console.error('Error booking transfer:', error);
    throw error;
  }
};

// Function to manage a transfer (e.g., cancellation)
const manageTransfer = async (manageData) => {
  try {
    const response = await amadeus.booking.transferOrders.cancel(
      JSON.stringify(manageData)
    );
    return response.data;
  } catch (error) {
    console.error('Error managing transfer:', error);
    throw error;
  }
};

module.exports = {
  searchTransfers,
  bookTransfer,
  manageTransfer
};
