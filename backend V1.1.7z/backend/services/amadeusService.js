const Amadeus = require('amadeus');

// Initialize the Amadeus API client
const amadeus = new Amadeus({
  clientId: process.env.AMADEUS_CLIENT_ID,
  clientSecret: process.env.AMADEUS_CLIENT_SECRET,
});

// Function to search for flights
const searchFlights = async (origin, destination, departureDate) => {
  try {
    const response = await amadeus.shopping.flightOffersSearch.get({
      originLocationCode: origin,
      destinationLocationCode: destination,
      departureDate: departureDate,
      adults: '1',  // Adjust the number of passengers dynamically as needed
    });
    return response.data;
  } catch (error) {
    handleError('flight search', error);
    throw error;
  }
};

// Confirm flight pricing
const confirmFlightAmadeus = async (flightOffer) => {
  try {
    if (!flightOffer) {
      throw new Error("The flightOffer data is undefined or null");
    }

    const payload = {
      data: {
        type: 'flight-offers-pricing',
        flightOffers: [flightOffer],
      },
    };

    console.log('Payload being sent to Amadeus (Flight Pricing):', JSON.stringify(payload, null, 2));

    const response = await amadeus.shopping.flightOffers.pricing.post(JSON.stringify(payload));
    return response.data;
  } catch (error) {
    handleError('flight pricing', error);
    throw error;
  }
};

// Book flight
const bookFlightAmadeus = async (flightOffer, travelers) => {
  try {
    const payload = JSON.stringify({
      data: {
        type: 'flight-order',
        flightOffers: [flightOffer],
        travelers: travelers,
      },
    });

    console.log('Payload being sent to Amadeus (Booking):', payload);

    const response = await amadeus.booking.flightOrders.post(payload);
    return response.data;
  } catch (error) {
    handleError('flight booking', error);
    throw error;
  }
};

// Retrieve a specific flight order by ID
const getFlightOrderById = async (orderId) => {
  try {
    // Ensure that the orderId is correct
    console.log('Retrieving flight order with ID:', orderId);

    // Make a call to the Amadeus API to retrieve the flight order details
    const response = await amadeus.booking.flightOrder(orderId).get();
    
    return response.data;
  } catch (error) {
    console.error('Error in retrieve flight order:', error.response ? error.response.data : error.message);
    console.error('Status:', error.response ? error.response.status : 'undefined');
    throw error;
  }
};

// Function to cancel a flight order with Amadeus
const cancelFlightOrder = async (orderId) => {
  try {
    // Send request to Amadeus to cancel the flight order
    const response = await amadeus.booking.flightOrder(orderId).delete();
    return response.data;
  } catch (error) {
    console.error('Error canceling flight order:', error.response ? error.response.data : error.message);
    throw error;
  }
};

// General error handling function
const handleError = (operation, error) => {
  if (error.response) {
    console.error(`Error in ${operation}:`, error.response.data);
    console.error('Status:', error.response.status);
  } else if (error.request) {
    console.error(`No response received during ${operation}:`, error.request);
  } else {
    console.error(`Error during ${operation}:`, error.message);
  }
};

module.exports = {
  searchFlights,
  confirmFlightAmadeus,
  bookFlightAmadeus,
  getFlightOrderById,
  cancelFlightOrder,
};
