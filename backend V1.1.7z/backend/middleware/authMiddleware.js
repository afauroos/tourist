const jwt = require('jsonwebtoken');

const authMiddleware = (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ message: 'Authorization header missing or malformed' });
    }

    const token = authHeader.split(' ')[1]; // Extract the token from 'Bearer <token>'

    // Verify the JWT using the secret
    jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
      if (err) {
        return res.status(401).json({ message: 'Invalid or expired token' });
      }

      // Ensure the decoded payload has userId
      if (!decoded || !decoded.userId) {
        return res.status(401).json({ message: 'Invalid token payload' });
      }

      // Attach the decoded user information to the request object
      req.user = { userId: decoded.userId }; // Attach only the relevant user information

      // Proceed to the next middleware or route handler
      next();
    });

  } catch (error) {
    console.error('Authentication error:', error);
    return res.status(500).json({ message: 'Internal server error' });
  }
};

module.exports = authMiddleware;
