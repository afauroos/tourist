const express = require('express');
const router = express.Router();
const { register, login, getProfile } = require('../controllers/authController');
const authMiddleware = require('../middleware/authMiddleware');

// Existing routes
router.post('/register', register);
router.post('/login', login);

// Add this route to handle profile requests
router.get('/profile', authMiddleware, getProfile);

module.exports = router;
