const express = require('express');
const router = express.Router();
const { 
  confirmFlight, 
  bookFlight, 
  getUserBookings, 
  getBookingById, 
  cancelBooking 
} = require('../controllers/bookingController'); // Destructure only the needed methods
const { searchFlights } = require('../services/amadeusService');
const authMiddleware = require('../middleware/authMiddleware');

// Search for flights
router.get('/flights', authMiddleware, async (req, res) => {
  try {
    const { origin, destination, departureDate } = req.query;
    const flights = await searchFlights(origin, destination, departureDate);
    res.json(flights);
  } catch (error) {
    res.status(500).json({ error: 'Failed to search flights' });
  }
});

// Route to confirm flight pricing
router.post('/flight-confirmation', authMiddleware, confirmFlight);

// Book a flight
router.post('/bookings/flight', authMiddleware, bookFlight);

// Retrieve all bookings for the user
router.get('/bookings', authMiddleware, getUserBookings);

// Retrieve a specific booking by its ID
router.get('/bookings/:bookingId', authMiddleware, getBookingById);

// Cancel a specific booking
router.delete('/bookings/:bookingId', authMiddleware, cancelBooking);

module.exports = router;
