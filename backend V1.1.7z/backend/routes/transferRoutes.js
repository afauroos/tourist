const express = require('express');
const { searchTransfers } = require('../services/amadeusService');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

router.post('/search', authMiddleware, async (req, res) => {
    try {
        const transferData = await searchTransfers(req.body);
        res.json(transferData);
    } catch (error) {
        res.status(500).json({ error: 'Failed to search transfers' });
    }
});

module.exports = router;
